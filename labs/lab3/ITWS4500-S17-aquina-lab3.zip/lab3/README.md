Our project will be hosted at http://websci.w1bbb.com/.
https://github.com/dawneraq/websci
https://github.com/ddbruce/websci-group-2

# Observations

"Bug tracking software" is pretty loosely defined, so I figured Github issues would suffice.

# Questions